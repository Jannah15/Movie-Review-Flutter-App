import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'movie_review.dart';

class ReviewsPage extends StatefulWidget {
  const ReviewsPage({super.key});

  @override
  _ReviewsPageState createState() => _ReviewsPageState();
}

class _ReviewsPageState extends State<ReviewsPage> {
  // This will hold the movie data from Firestore
  List<Map<String, dynamic>> movies = [];

  @override
  void initState() {
    super.initState();
    _fetchMovies();
  }

  // Fetch movies data from Firestore
  Future<void> _fetchMovies() async {
    try {
      final snapshot = await FirebaseFirestore.instance.collection('movies').get();
      final List<Map<String, dynamic>> movieList = [];
      for (var doc in snapshot.docs) {
        movieList.add({
          'title': doc['title'],
          'rating': doc['rating'],
          'poster': doc['poster'],
        });
      }
      setState(() {
        movies = movieList;
      });
    } catch (e) {
      // Handle errors
      print('Error fetching movies: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20),
            Text(
              'Featured Reviews',
              style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Check out what users are saying about these top-rated movies! '
              'Get insights from our community on their thoughts and ratings.',
              style: TextStyle(
                fontSize: 16,
                color: Colors.white70,
              ),
            ),
            const SizedBox(height: 20),

            // Movie reviews list
            Expanded(
              child: movies.isEmpty
                  ? const Center(child: CircularProgressIndicator()) // Show a loading spinner if no movies are loaded
                  : ListView.separated(
                      itemCount: movies.length,
                      separatorBuilder: (context, index) => const Divider(
                        color: Colors.grey,
                        height: 2,
                        thickness: 2,
                        indent: 16,
                        endIndent: 16,
                      ),
                      itemBuilder: (context, index) {
                        final movie = movies[index];
                        return _buildMovieTile(context, movie);
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMovieTile(BuildContext context, Map<String, dynamic> movie) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => MovieReviewPage(
              movieTitle: movie['title'],
              posterPath: movie['poster'],
            ),
          ),
        );
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                movie['poster'], // Load poster image from URL
                width: 100,
                height: 150,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    movie['title'],
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 8),
                  _buildStarRating(movie['rating']),
                  const SizedBox(height: 6),
                  Text(
                    '${movie['rating']}/5',
                    style: const TextStyle(
                      fontSize: 16,
                      color: Colors.white70,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStarRating(double rating) {
    const int totalStars = 5;
    List<Widget> stars = [];

    for (int i = 1; i <= totalStars; i++) {
      if (rating >= i) {
        stars.add(const Icon(Icons.star, color: Colors.amber, size: 24));
      } else if (rating >= i - 0.5) {
        stars.add(const Icon(Icons.star_half, color: Colors.amber, size: 24));
      } else {
        stars.add(const Icon(Icons.star_border, color: Colors.amber, size: 24));
      }
    }

    return Row(children: stars);
  }
}
