import 'package:flutter/material.dart';
import 'movie_details.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class MovieListPage extends StatefulWidget {
  const MovieListPage({super.key});

  @override
  _MovieListPageState createState() => _MovieListPageState();
}

class _MovieListPageState extends State<MovieListPage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String selectedGenre = 'All';
  final List<String> genres = ['All', 'Action', 'Comedy', 'Drama', 'Sci-Fi', 'Romance', 'Musical'];
  List<Map<String, dynamic>> movies = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _tabController.addListener(() {
      setState(() {});
    });
    _fetchMovies();
  }

  Future<void> _fetchMovies() async {
    try {
      var snapshot = await FirebaseFirestore.instance.collection('movies').get();
      List<Map<String, dynamic>> fetchedMovies = [];
      for (var doc in snapshot.docs) {
        var movieData = doc.data();
        movieData['id'] = doc.id; // Store document ID
        fetchedMovies.add(movieData);
      }
      setState(() {
        movies = fetchedMovies;
      });
    } catch (e) {
      print("Error fetching movies: $e");
    }
  }

  List<Map<String, dynamic>> _filterByTab(List<Map<String, dynamic>> movieList) {
    switch (_tabController.index) {
      case 1:
        return movieList.where((movie) => (movie['rating'] ?? 0) >= 4.5).toList();
      case 2:
        return movieList.where((movie) {
          final releaseDate = movie['release_date'];
          if (releaseDate is Timestamp) {
            final now = DateTime.now();
            return releaseDate.toDate().isAfter(now.subtract(const Duration(days: 90)));
          }
          return false;
        }).toList();
      case 3:
        return List<Map<String, dynamic>>.from(movieList)
          ..sort((a, b) => ((b['popularity'] ?? 0).compareTo(a['popularity'] ?? 0)));
      default:
        return movieList;
    }
  }

  @override
  Widget build(BuildContext context) {
    final genreFiltered = selectedGenre == 'All'
        ? movies
        : movies.where((movie) => movie['genre'] == selectedGenre).toList();

    final filteredMovies = _filterByTab(genreFiltered);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text('Featured Movies'),
        iconTheme: const IconThemeData(color: Colors.white),
        titleTextStyle: const TextStyle(color: Colors.white, fontSize: 20),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(100),
          child: Column(
            children: [
              TabBar(
                controller: _tabController,
                tabs: const [
                  Tab(text: 'All'),
                  Tab(text: 'Top Rated'),
                  Tab(text: 'New Releases'),
                  Tab(text: 'Most Popular'),
                ],
                indicatorColor: Colors.white,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: DropdownButton<String>(
                  value: selectedGenre,
                  dropdownColor: Colors.black,
                  style: const TextStyle(color: Colors.white),
                  iconEnabledColor: Colors.white,
                  onChanged: (newValue) {
                    setState(() {
                      selectedGenre = newValue!;
                    });
                  },
                  items: genres.map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: movies.isEmpty
            ? const Center(child: CircularProgressIndicator())
            : GridView.builder(
                itemCount: filteredMovies.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 0.65,
                ),
                itemBuilder: (context, index) {
                  final movie = filteredMovies[index];
                  return MovieCard(
                    movieId: movie['id'],
                    title: movie['title'],
                    posterAsset: movie['poster'],
                    rating: movie['rating'],
                    description: movie['description'],
                    cast: List<String>.from(movie['cast'] ?? []),
                    synopsis: movie['synopsis'],
                    directors: List<String>.from(movie['directors'] ?? []),
                    writers: List<String>.from(movie['writers'] ?? []),
                  );
                },
              ),
      ),
    );
  }
}

class MovieCard extends StatefulWidget {
  final String movieId;
  final String title;
  final String posterAsset;
  final double rating;
  final String description;
  final List<String> cast;
  final String synopsis;
  final List<String> directors;
  final List<String> writers;

  const MovieCard({
    super.key,
    required this.movieId,
    required this.title,
    required this.posterAsset,
    required this.rating,
    required this.description,
    required this.cast,
    required this.synopsis,
    required this.directors,
    required this.writers,
  });

  @override
  State<MovieCard> createState() => _MovieCardState();
}

class _MovieCardState extends State<MovieCard> {
  bool isHovered = false;
  bool _isInWatchlist = false;

  @override
  void initState() {
    super.initState();
    _checkWatchlistStatus();
  }

  Future<void> _checkWatchlistStatus() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final watchlistRef = FirebaseFirestore.instance
        .collection('watchlists')
        .doc(user.uid);

    final snapshot = await watchlistRef.get();
    if (snapshot.exists) {
      final watchlist = List<String>.from(snapshot.data()?['movies'] ?? []);
      setState(() {
        _isInWatchlist = watchlist.contains(widget.movieId);
      });
    }
  }

  Future<void> _toggleWatchlist() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please sign in to use watchlist')),
      );
      return;
    }

    final watchlistRef = FirebaseFirestore.instance
        .collection('watchlists')
        .doc(user.uid);

    try {
      if (_isInWatchlist) {
        await watchlistRef.update({
          'movies': FieldValue.arrayRemove([widget.movieId])
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${widget.title} removed from watchlist')),
        );
      } else {
        await watchlistRef.set({
          'movies': FieldValue.arrayUnion([widget.movieId])
        }, SetOptions(merge: true));
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${widget.title} added to watchlist')),
        );
      }
      setState(() {
        _isInWatchlist = !_isInWatchlist;
      });
    } catch (e) {
      print('Error updating watchlist: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to update watchlist')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => isHovered = true),
      onExit: (_) => setState(() => isHovered = false),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                AspectRatio(
                  aspectRatio: 2 / 3,
                  child: Image.asset(
                    widget.posterAsset,
                    fit: BoxFit.cover,
                  ),
                ),
                Flexible(
                  child: SingleChildScrollView(
                    child: Container(
                      color: const Color(0xFF1E1E1E),
                      padding: const EdgeInsets.all(8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.title,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            widget.description,
                            style: const TextStyle(color: Colors.white),
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 8),
                          OutlinedButton.icon(
                            onPressed: _toggleWatchlist,
                            icon: Icon(_isInWatchlist ? Icons.check : Icons.add),
                            label: Text(_isInWatchlist ? "In Watchlist" : "Watchlist"),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.white,
                              side: const BorderSide(color: Colors.white24),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                            ),
                          ),
                          TextButton.icon(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => MovieDetailsPage(
                                    title: widget.title,
                                    posterAsset: widget.posterAsset,
                                    rating: widget.rating,
                                    description: widget.description,
                                    cast: widget.cast,
                                    synopsis: widget.synopsis,
                                    directors: widget.directors,
                                    writers: widget.writers,
                                  ),
                                ),
                              );
                            },
                            icon: const Icon(Icons.info_outline),
                            label: const Text("See Details"),
                            style: TextButton.styleFrom(
                              foregroundColor: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
            AnimatedPositioned(
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeInOut,
              bottom: isHovered ? 0 : -120,
              left: 0,
              right: 0,
              child: Container(
                color: Colors.black.withOpacity(0.9),
                padding: const EdgeInsets.all(8),
                child: Column(
                  children: [
                    Text(
                      widget.title,
                      style: const TextStyle(color: Colors.white),
                    ),
                    const SizedBox(height: 8),
                    if (isHovered) ...[
                      Row(
                        children: [
                          const Icon(Icons.star, color: Colors.amber, size: 18),
                          const SizedBox(width: 4),
                          Text(
                            widget.rating.toString(),
                            style: const TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                    ],
                    const SizedBox(height: 8),
                    Text(
                      widget.description,
                      style: const TextStyle(color: Colors.white),
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    OutlinedButton.icon(
                      onPressed: _toggleWatchlist,
                      icon: Icon(_isInWatchlist ? Icons.check : Icons.add),
                      label: Text(_isInWatchlist ? "In Watchlist" : "Watchlist"),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.white,
                        side: const BorderSide(color: Colors.white24),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                      ),
                    ),
                    TextButton.icon(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => MovieDetailsPage(
                              title: widget.title,
                              posterAsset: widget.posterAsset,
                              rating: widget.rating,
                              description: widget.description,
                              cast: widget.cast,
                              synopsis: widget.synopsis,
                              directors: widget.directors,
                              writers: widget.writers,
                            ),
                          ),
                        );
                      },
                      icon: const Icon(Icons.info_outline),
                      label: const Text("See Details"),
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}