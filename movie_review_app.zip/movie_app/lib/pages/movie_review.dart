import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../widgets/rating_bar.dart';

class MovieReviewPage extends StatefulWidget {
  final String movieTitle;
  final String posterPath;

  const MovieReviewPage({
    super.key,
    required this.movieTitle,
    required this.posterPath,
  });

  @override
  State<MovieReviewPage> createState() => _MovieReviewPageState();
}

class _MovieReviewPageState extends State<MovieReviewPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  late CollectionReference reviewsRef;
  List<Map<String, dynamic>> reviews = [];

  double newRating = 4.0;
  final TextEditingController _reviewController = TextEditingController();
  final Map<int, TextEditingController> _reviewInputControllers = {};

  @override
  void initState() {
    super.initState();
    reviewsRef = _firestore.collection('reviews');
    _fetchReviews();
  }

  void _fetchReviews() async {
    QuerySnapshot snapshot = await reviewsRef
        .where('movieTitle', isEqualTo: widget.movieTitle)
        .orderBy('timestamp', descending: true)
        .get();

    setState(() {
      reviews = snapshot.docs.map((doc) {
        return {
          'id': doc.id, // Store document ID
          'username': doc['username'],
          'rating': doc['rating'],
          'review': doc['review'],
          'likes': doc['likes'],
          'comments': List<String>.from(doc['comments']),
        };
      }).toList();
    });
  }

  void _submitReview() async {
    final review = _reviewController.text.trim();
    if (review.isEmpty) return;

    final docRef = await reviewsRef.add({
      'movieTitle': widget.movieTitle,
      'username': 'You',
      'rating': newRating,
      'review': review,
      'likes': 0,
      'comments': [],
      'timestamp': FieldValue.serverTimestamp(),
    });

    setState(() {
      reviews.insert(0, {
        'id': docRef.id, // Store the document ID here as well
        'username': 'You',
        'rating': newRating,
        'review': review,
        'likes': 0,
        'comments': [],
      });
      _reviewController.clear();
      newRating = 4.0;
    });

    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Review added!')));
  }

  void _addLike(int index) async {
    final reviewId = reviews[index]['id'];
    final reviewDoc = reviewsRef.doc(reviewId);

    await reviewDoc.update({
      'likes': FieldValue.increment(1),
    });

    setState(() {
      reviews[index]['likes'] += 1;
    });
  }

  void _addComment(int index, String comment) async {
    final reviewId = reviews[index]['id'];
    final reviewDoc = reviewsRef.doc(reviewId);

    await reviewDoc.update({
      'comments': FieldValue.arrayUnion([comment]),
    });

    setState(() {
      reviews[index]['comments'].add(comment);
    });
  }

  @override
  void dispose() {
    _reviewController.dispose();
    _reviewInputControllers.values.forEach((controller) => controller.dispose());
    super.dispose();
  }

  Widget _buildStarRow(double rating) {
    return Row(
      children: List.generate(5, (i) {
        final isFull = rating >= i + 1;
        final isHalf = rating > i && rating < i + 1;
        return Icon(
          isFull
              ? Icons.star
              : isHalf
              ? Icons.star_half
              : Icons.star_border,
          size: 20,
          color: Colors.amber,
        );
      }),
    );
  }

  Widget _buildReviewCard(Map<String, dynamic> review, int index) {
    _reviewInputControllers.putIfAbsent(index, () => TextEditingController());

    return Card(
      color: Colors.grey[900],
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              review['username'],
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            _buildStarRow(review['rating']),
            const SizedBox(height: 8),
            Text(review['review']),
            const SizedBox(height: 8),
            Row(
              children: [
                IconButton(
                  onPressed: () => _addLike(index),
                  icon: const Icon(Icons.favorite, color: Colors.red),
                ),
                Text('${review['likes']}'),
                const SizedBox(width: 16),
                const Icon(Icons.comment, color: Colors.blue),
                Text(' ${review['comments'].length}'),
              ],
            ),
            const SizedBox(height: 8),
            ...review['comments'].map<Widget>((c) {
              return Padding(
                padding: const EdgeInsets.only(left: 8, top: 4),
                child: Text('💬 $c'),
              );
            }).toList(),
            const SizedBox(height: 8),
            TextField(
              controller: _reviewInputControllers[index],
              decoration: InputDecoration(
                hintText: 'Add a comment...',
                filled: true,
                fillColor: Colors.grey[800],
                contentPadding: const EdgeInsets.symmetric(horizontal: 8),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              onSubmitted: (val) {
                if (val.trim().isNotEmpty) {
                  _addComment(index, val.trim());
                  _reviewInputControllers[index]?.clear();
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('${widget.movieTitle} Reviews')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: Column(
              children: [
                Container(
                  height: 300,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    image: DecorationImage(
                      image: AssetImage(widget.posterPath),
                      fit: BoxFit.contain,
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  widget.movieTitle,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          const Text('Write a Review:', style: TextStyle(fontSize: 20)),
          const SizedBox(height: 12),
          CustomRatingBar(
            initialRating: newRating,
            itemSize: 30,
            allowHalfRating: true,
            onRatingUpdate: (rating) {
              setState(() {
                newRating = rating;
              });
            },
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _reviewController,
            maxLines: 3,
            decoration: InputDecoration(
              hintText: 'Your thoughts...',
              filled: true,
              fillColor: Colors.grey[850],
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
          const SizedBox(height: 8),
          ElevatedButton(
            onPressed: _submitReview,
            child: const Text('Submit Review'),
          ),
          const SizedBox(height: 24),
          const Text('User Reviews:', style: TextStyle(fontSize: 20)),
          const SizedBox(height: 12),
          ...reviews.asMap().entries.map(
            (entry) => _buildReviewCard(entry.value, entry.key),
          ),
        ],
      ),
    );
  }
}
