import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'movie_details.dart';

class UserProfilePage extends StatefulWidget {
  const UserProfilePage({super.key});

  @override
  State<UserProfilePage> createState() => _UserProfilePageState();
}

class _UserProfilePageState extends State<UserProfilePage> {
  final TextEditingController _usernameController = TextEditingController();
  final ImagePicker _picker = ImagePicker();
  String? _profilePicturePath;
  String _username = "Your Username";
  Uint8List? _profilePictureBytes;
  bool _isEditingUsername = false;
  List<String> _watchlistMovieIds = [];
  bool _isLoadingWatchlist = true;
  List<Map<String, dynamic>> _watchlistMovies = [];

  @override
  void initState() {
    super.initState();
    _loadProfileData();
    _loadWatchlist();
  }

  Future<void> _loadProfileData() async {
    final prefs = await SharedPreferences.getInstance();
    final currentUser = FirebaseAuth.instance.currentUser;

    setState(() {
      _username = prefs.getString('username') ??
          (currentUser?.displayName ??
              currentUser?.email?.split('@')[0] ?? 'Your Username');
      _profilePicturePath = prefs.getString('profile_picture');
      _usernameController.text = _username;
    });
  }

  Future<void> _saveProfileData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('username', _usernameController.text);
    if (_profilePicturePath != null) {
      await prefs.setString('profile_picture', _profilePicturePath!);
    }
  }

  Future<void> _loadWatchlist() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final watchlistRef = FirebaseFirestore.instance
          .collection('watchlists')
          .doc(user.uid);

      final snapshot = await watchlistRef.get();
      if (snapshot.exists) {
        final watchlist = List<String>.from(snapshot.data()?['movies'] ?? []);
        setState(() {
          _watchlistMovieIds = watchlist;
        });

        if (_watchlistMovieIds.isNotEmpty) {
          final moviesSnapshot = await FirebaseFirestore.instance
              .collection('movies')
              .where(FieldPath.documentId, whereIn: _watchlistMovieIds)
              .get();

          setState(() {
            _watchlistMovies = moviesSnapshot.docs
                .map((doc) => doc.data()..['id'] = doc.id)
                .toList();
            _isLoadingWatchlist = false;
          });
        } else {
          setState(() {
            _isLoadingWatchlist = false;
          });
        }
      } else {
        setState(() {
          _isLoadingWatchlist = false;
        });
      }
    } catch (e) {
      print('Error loading watchlist: $e');
      setState(() {
        _isLoadingWatchlist = false;
      });
    }
  }

  Future<void> _removeFromWatchlist(String movieId) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final watchlistRef = FirebaseFirestore.instance
          .collection('watchlists')
          .doc(user.uid);

      await watchlistRef.update({
        'movies': FieldValue.arrayRemove([movieId])
      });

      setState(() {
        _watchlistMovieIds.remove(movieId);
        _watchlistMovies.removeWhere((movie) => movie['id'] == movieId);
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Removed from watchlist')),
      );
    } catch (e) {
      print('Error removing from watchlist: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to remove from watchlist')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('User Profile'),
        backgroundColor: Colors.black,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: GestureDetector(
                  onTap: _changeProfilePicture,
                  child: CircleAvatar(
                    radius: 50,
                    backgroundImage: _getProfileImage(),
                    child: _profilePicturePath == null
                        ? const Icon(Icons.camera_alt, color: Colors.white)
                        : null,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _usernameController,
                      decoration: const InputDecoration(
                        labelText: 'Username',
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
                      ),
                      onChanged: (text) {
                        _username = text;
                      },
                      enabled: _isEditingUsername,
                    ),
                  ),
                  IconButton(
                    icon: Icon(
                      _isEditingUsername ? Icons.save : Icons.edit,
                      color: Colors.amber,
                    ),
                    onPressed: () {
                      if (_isEditingUsername) {
                        _saveProfileData();
                      }
                      setState(() {
                        _isEditingUsername = !_isEditingUsername;
                      });
                    },
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Text(
                'Your Lists',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              _buildListOption('Watchlist', Icons.bookmark, 'watchlist'),
              _buildListOption('Favorites', Icons.favorite, 'favorites'),
              _buildListOption('New List', Icons.add, 'new_list'),
            ],
          ),
        ),
      ),
    );
  }

  ImageProvider _getProfileImage() {
    if (_profilePictureBytes == null) {
      return const AssetImage('assets/images/profile_picture.jpg');
    } else if (kIsWeb) {
      return MemoryImage(_profilePictureBytes!);
    } else {
      return FileImage(File(_profilePicturePath!));
    }
  }

  Future<void> _changeProfilePicture() async {
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      setState(() {
        if (kIsWeb) {
          image.readAsBytes().then((bytes) {
            setState(() {
              _profilePictureBytes = bytes;
            });
            _saveProfileData();
          });
        } else {
          _profilePicturePath = image.path;
          _profilePictureBytes = null;
          _saveProfileData();
        }
      });
    }
  }

  Widget _buildListOption(String listName, IconData icon, String listType) {
    if (listType == 'watchlist') {
      return Card(
        margin: const EdgeInsets.symmetric(vertical: 8),
        child: ExpansionTile(
          initiallyExpanded: true,
          leading: Icon(icon, color: Colors.amber),
          title: Text(listName),
          children: [
            if (_isLoadingWatchlist)
              const Padding(
                padding: EdgeInsets.all(16.0),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (_watchlistMovies.isEmpty)
              const Padding(
                padding: EdgeInsets.all(16.0),
                child: Text('No movies in watchlist'),
              )
            else
              SizedBox(
                height: 200, // Fixed height for the list
                child: ListView.builder(
                  shrinkWrap: true,
                  physics: const ClampingScrollPhysics(),
                  itemCount: _watchlistMovies.length,
                  itemBuilder: (context, index) {
                    final movie = _watchlistMovies[index];
                    return ListTile(
                      leading: Image.asset(
                        movie['poster'],
                        width: 40,
                        height: 60,
                        fit: BoxFit.cover,
                      ),
                      title: Text(movie['title']),
                      subtitle: Row(
                        children: [
                          const Icon(Icons.star, color: Colors.amber, size: 16),
                          const SizedBox(width: 4),
                          Text(movie['rating'].toString()),
                        ],
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.remove, color: Colors.red),
                        onPressed: () => _removeFromWatchlist(movie['id']),
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => MovieDetailsPage(
                              title: movie['title'],
                              posterAsset: movie['poster'],
                              rating: movie['rating'],
                              description: movie['description'],
                              cast: List<String>.from(movie['cast'] ?? []),
                              synopsis: movie['synopsis'],
                              directors: List<String>.from(movie['directors'] ?? []),
                              writers: List<String>.from(movie['writers'] ?? []),
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
          ],
        ),
      );
    } else {
      return Card(
        margin: const EdgeInsets.symmetric(vertical: 8),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(vertical: 4, horizontal: 16),
          title: Row(
            children: [
              Icon(icon, color: Colors.amber),
              const SizedBox(width: 8),
              Text(listName),
            ],
          ),
          trailing: IconButton(
            icon: const Icon(Icons.add, color: Colors.amber),
            onPressed: () {
              // Handle adding to list
            },
          ),
          onTap: () {
            // Handle navigation to list
          },
        ),
      );
    }
  }
}