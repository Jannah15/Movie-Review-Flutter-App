import 'package:flutter/material.dart';
import 'movie_list.dart';
import 'user_profile.dart';
import 'reviews.dart';
import '../widgets/search_bar_widget.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  final List<Widget> _pages = <Widget>[
    const HomeContent(),
    const MovieListPage(),
    const ReviewsPage(),
    const UserProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(70),
        child: AppBar(
          backgroundColor: Colors.black,
          automaticallyImplyLeading: false,
          title: Row(
            children: [
              Container(
                margin: const EdgeInsets.only(right: 16),
                child: Image.asset(
                  'assets/images/logo_transparent.png',
                  width: 140,
                  height: 60,
                  fit: BoxFit.contain,
                ),
              ),
              Expanded(
                child: Align(
                  alignment: Alignment.center,
                  child: SizedBox(height: 40, child: const SearchBarWidget()),
                ),
              ),
              const SizedBox(width: 16),
              GestureDetector(
                onTap: () {
                  setState(() {
                    _selectedIndex = 3; // Navigate to Profile tab
                  });
                },
                child: const CircleAvatar(
                  radius: 20,
                  backgroundImage: AssetImage(
                    'assets/images/profile_picture.jpg',
                  ),
                ),
              ),
            ],
          ),
        ),
      ),

      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: Color(0xFFB39DDB),
        unselectedItemColor: Colors.grey,
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.movie), label: 'Movies'),
          BottomNavigationBarItem(icon: Icon(Icons.comment), label: 'Reviews'),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_circle),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}

class HomeContent extends StatefulWidget {
  const HomeContent({super.key});

  @override
  _HomeContentState createState() => _HomeContentState();
}

class _HomeContentState extends State<HomeContent> {
  final PageController _pageController = PageController(viewportFraction: 0.8);
  int _currentPage = 0;

  void _nextPage() {
    if (_currentPage < 2) {
      _pageController.animateToPage(
        _currentPage + 1,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  void _previousPage() {
    if (_currentPage > 0) {
      _pageController.animateToPage(
        _currentPage - 1,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '🎬 Featured Movies',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Stack(
            children: [
              SizedBox(
                height: 220,
                child: PageView.builder(
                  controller: _pageController,
                  onPageChanged: (index) {
                    setState(() {
                      _currentPage = index;
                    });
                  },
                  itemCount: 3, // Number of movies to display
                  itemBuilder: (context, index) {
                    return _buildFeaturedMovieCard(
                      _getMovieTitle(index),
                      _getMovieImage(index),
                    );
                  },
                ),
              ),
              // Left Arrow
              Positioned(
                left: 8,
                top: 90,
                child: IconButton(
                  icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
                  onPressed: _previousPage,
                ),
              ),
              // Right Arrow
              Positioned(
                right: 8,
                top: 90,
                child: IconButton(
                  icon: const Icon(
                    Icons.arrow_forward_ios,
                    color: Colors.white,
                  ),
                  onPressed: _nextPage,
                ),
              ),
            ],
          ),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const MovieListPage()),
                );
              },
              child: const Text(
                'Show More',
                style: TextStyle(color: Color(0xFFB39DDB)),
              ),
            ),
          ),
          const SizedBox(height: 24),
          Row(
            children: const [
              Icon(Icons.rate_review, color: Colors.grey),
              SizedBox(width: 8),
              Text(
                'Latest Reviews',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Column(
            children: [
              _buildReviewSnippet('Inception', 'A mind-bending masterpiece!'),
              _buildReviewSnippet(
                'The Matrix',
                'Still relevant and thrilling.',
              ),
              _buildReviewSnippet(
                'Interstellar',
                'Visually stunning with emotional depth.',
              ),
            ],
          ),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ReviewsPage()),
                );
              },
              child: const Text(
                'Show More',
                style: TextStyle(color: Color(0xFFB39DDB)),
              ),
            ),
          ),
          const SizedBox(height: 32),
          Center(
            child: Text(
              '⭐ Welcome to FilmStarred! Discover movies, rate them, and share your thoughts.',
              style: TextStyle(fontSize: 16, color: Colors.grey[700]),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }

  String _getMovieTitle(int index) {
    switch (index) {
      case 0:
        return 'Inception';
      case 1:
        return 'The Matrix';
      case 2:
        return 'Interstellar';
      default:
        return 'Inception';
    }
  }

  String _getMovieImage(int index) {
    switch (index) {
      case 0:
        return 'assets/images/inception.jpg';
      case 1:
        return 'assets/images/matrix.jpg';
      case 2:
        return 'assets/images/interstellar.jpg';
      default:
        return 'assets/images/inception.jpg';
    }
  }

  Widget _buildFeaturedMovieCard(String title, String imagePath) {
    return Container(
      width: 160,
      margin: const EdgeInsets.symmetric(horizontal: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: Colors.black12,
        image: DecorationImage(
          image: AssetImage(imagePath),
          fit: BoxFit.contain, // Ensures the entire image is shown
          alignment: Alignment.center,
        ),
      ),
      child: Align(
        alignment: Alignment.bottomLeft,
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.white,
              shadows: [Shadow(color: Colors.black, blurRadius: 5)],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildReviewSnippet(String movieTitle, String review) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      elevation: 2,
      child: ListTile(
        leading: const Icon(Icons.comment, color: Colors.amber),
        title: Text(
          movieTitle,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(review),
      ),
    );
  }
}
