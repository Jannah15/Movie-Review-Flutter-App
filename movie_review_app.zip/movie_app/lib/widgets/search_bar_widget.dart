import 'package:flutter/material.dart' hide BoxDecoration, BoxShadow;
import 'package:flutter_inset_shadow/flutter_inset_shadow.dart';

class SearchBarWidget extends StatefulWidget {
  const SearchBarWidget({super.key});

  @override
  State<SearchBarWidget> createState() => _SearchBarWidgetState();
}

class _SearchBarWidgetState extends State<SearchBarWidget> {
  // tracks if the text field is focused or not
  bool _isFocused = false;
  bool _isHovered = false; // track hover state

  final TextEditingController _controller = TextEditingController();

  // detect focus changes
  final FocusNode _focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    // Add listener to detect focus change
    _focusNode.addListener(() {
      setState(() {
        _isFocused = _focusNode.hasFocus;
      });
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PrimaryContainer(
      child: Container(
        width: 250, 
        child: TextField(
          onChanged: (value) {},
          style: const TextStyle(fontSize: 16, color: Colors.white),
          textAlignVertical: TextAlignVertical.center,
          controller: _controller,
          focusNode: _focusNode, // Assign the FocusNode 
          decoration: InputDecoration(
            contentPadding: const EdgeInsets.only(left: 20, right: 20, bottom: 3),
            border: InputBorder.none,
            filled: false,
            focusedBorder: InputBorder.none,
            errorBorder: InputBorder.none,
            disabledBorder: InputBorder.none,
            enabledBorder: InputBorder.none,
            hintText: 'Search',
            hintStyle: const TextStyle(fontSize: 14, color: Colors.grey),
            suffixIcon: MouseRegion(
              onEnter: (_) {
                setState(() {
                  _isHovered = true; // Set hover to true when mouse enters
                });
              },
              onExit: (_) {
                setState(() {
                  _isHovered = false; // Set hover to false when mouse exits
                });
              },
              child: AnimatedScale(
                scale: (_isHovered || _isFocused) ? 1.2 : 1.0, // Animate scale when hovered or focused
                duration: const Duration(milliseconds: 300),
                child: Container(
                  width: 40,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0XFF5E5E5E), Color(0XFF3E3E3E)],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: const Icon(Icons.search, color: Color(0xFF222222)),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class PrimaryContainer extends StatelessWidget {
  final Widget child;
  final double? radius;
  final Color? color;
  const PrimaryContainer({
    super.key,
    this.radius,
    this.color,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius ?? 30),
        boxShadow: [
          BoxShadow(color: color ?? const Color(0XFF1E1E1E)),
          const BoxShadow(
            offset: Offset(2, 2),
            blurRadius: 4,
            spreadRadius: 0,
            color: Colors.black,
            inset: true,
          ),
        ],
      ),
      child: child,
    );
  }
}
