import 'package:flutter/material.dart';
import 'package:movie_app/pages/home_page.dart';
import 'pages/login.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../cubit/auth_cubit_cubit.dart'; // Ensure the AuthCubit is imported
import '../services/auth_service.dart'; // Import the AuthService

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  // Initialize AuthService
  final authService = AuthService(); // Create an instance of AuthService

  runApp(
    MyApp(authService: authService),
  ); // Pass the authService instance to MyApp
}

class MyApp extends StatelessWidget {
  final AuthService authService;

  const MyApp({super.key, required this.authService});

  @override
  Widget build(BuildContext context) {
    return BlocProvider<AuthCubit>(
      create:
          (context) => AuthCubit(authService), // Pass authService to AuthCubit
      child: MaterialApp(
        title: 'Movie App',
        theme: ThemeData(fontFamily: 'AfacadFlux'),
        themeMode: ThemeMode.dark, // Dark mode
        darkTheme: ThemeData(
          brightness: Brightness.dark,
          colorScheme: ColorScheme.fromSeed(
            seedColor: Colors.deepPurple,
            brightness: Brightness.dark,
          ),
          scaffoldBackgroundColor: Colors.black,
          appBarTheme: const AppBarTheme(
            backgroundColor: Colors.black,
            foregroundColor: Colors.white, // Title and icon color
          ),
          bottomNavigationBarTheme: const BottomNavigationBarThemeData(
            backgroundColor: Colors.black,
            selectedItemColor: Colors.deepPurpleAccent,
            unselectedItemColor: Colors.white70,
          ),
          textTheme: const TextTheme(
            bodyLarge: TextStyle(color: Colors.white, fontFamily: 'AfacadFlux'),
            bodyMedium: TextStyle(
              color: Colors.white70,
              fontFamily: 'AfacadFlux',
            ),
            titleLarge: TextStyle(
              color: Colors.white,
              fontFamily: 'AfacadFlux',
              fontWeight: FontWeight.bold,
            ),
            titleMedium: TextStyle(
              color: Colors.white70,
              fontFamily: 'AfacadFlux',
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        home: const LoginPage(),
        routes: {'/home': (context) => const HomePage()},
      ),
    );
  }
}
