import 'package:movie_app/cubit/auth_cubit_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../services/auth_service.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthCubit extends Cubit<AuthState> {
  final AuthService _authService;
  AuthCubit(this._authService) : super(AuthInitial()) {
    _authService.authStateChanges.listen((user) {
      emit(user == null ? Unauthenticated() : Authenticated());
    });
  }

  Future<void> signIn(String email, String password) async {
    emit(AuthLoading());
    try {
      await _authService.signIn(
        email: email,
        password: password,
      );
      emit(Authenticated());
    } on FirebaseAuthException catch (e) {
      emit(AuthError(e.message ?? 'An error occurred'));
    }
  }

  void register(String email, String password, String name) async {
    try {
      emit(AuthLoading());
      await _authService.register(
        email: email,
        password: password,
        name: name, 
      );
      emit(Authenticated());
    } catch (e) {
      emit(AuthError(e.toString()));
    }
  }

  void signOut() async {
    await _authService.signOut();
  }
}